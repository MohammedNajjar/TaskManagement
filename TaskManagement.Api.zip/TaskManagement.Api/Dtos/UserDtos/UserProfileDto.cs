using System.ComponentModel.DataAnnotations;

namespace TaskManagement.Api.Dtos.UserDtos;

public record class UserProfileDto
(
  int Id,
  string UserName


);
